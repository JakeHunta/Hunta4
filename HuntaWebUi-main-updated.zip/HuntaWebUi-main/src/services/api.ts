import axios from 'axios';

// Use proxy path for development, direct URL for production
const API_BASE_URL = import.meta.env.DEV ? '/api' : 'https://huntaweb2.onrender.com';

export interface BackendSearchResult {
  title: string;
  image: string;
  price: string;
  link: string;
  source: string;
  description: string;
  score: number;
}

export interface SearchRequest {
  search_term: string;
}

// Create axios instance with default config
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 60000, // 60 second timeout
  headers: {
    'Content-Type': 'application/json',
  },
});

export async function searchListings(searchTerm: string): Promise<BackendSearchResult[]> {
  try {
    console.log('🔍 Sending request to backend:', API_BASE_URL);
    console.log('📝 Search term:', searchTerm);

    const response = await apiClient.post<BackendSearchResult[]>('/search', {
      search_term: searchTerm.trim()
    });

    console.log('✅ Response received:', response.data);

    // Validate response data
    if (!Array.isArray(response.data)) {
      console.error('❌ Invalid response format:', response.data);
      throw new Error('Invalid response format: expected array of listings');
    }

    // Filter out invalid listings and ensure required fields exist
    const validListings = response.data.filter(listing => {
      const isValid = listing &&
        typeof listing.title === 'string' &&
        typeof listing.price === 'string' &&
        typeof listing.link === 'string' &&
        listing.title.trim().length > 0 &&
        listing.price.trim().length > 0 &&
        listing.link.trim().length > 0;
      
      if (!isValid) {
        console.warn('⚠️ Filtering out invalid listing:', listing);
      }
      
      return isValid;
    });

    console.log(`✅ Returning ${validListings.length} valid listings`);
    return validListings;
  } catch (error) {
    console.error('❌ Search error details:', error);
    
    if (axios.isAxiosError(error)) {
      if (error.code === 'ECONNABORTED') {
        throw new Error('Search request timed out. Please try again.');
      }
      if (error.response?.status === 404) {
        throw new Error('Search endpoint not found. Please check if the backend is running.');
      }
      if (error.response?.status >= 500) {
        throw new Error('Backend server error. Please try again later.');
      }
      if (error.response?.status === 0 || error.code === 'ERR_NETWORK') {
        throw new Error('Cannot connect to backend. Please make sure the backend server is running on port 3001.');
      }
      if (error.response?.data?.message) {
        throw new Error(error.response.data.message);
      }
      
      // Log the full error for debugging
      console.error('Full axios error:', {
        status: error.response?.status,
        statusText: error.response?.statusText,
        data: error.response?.data,
        code: error.code,
        message: error.message
      });
    }
    
    throw new Error('Failed to search listings. Please check your connection and try again.');
  }
}

// Health check function
export async function checkApiHealth(): Promise<boolean> {
  try {
    console.log('🏥 Checking API health...');
    const response = await apiClient.get('/health', { timeout: 10000 });
    console.log('✅ Health check passed:', response.status);
    return response.status === 200;
  } catch (error) {
    console.error('❌ Health check failed:', error);
    return false;
  }
}