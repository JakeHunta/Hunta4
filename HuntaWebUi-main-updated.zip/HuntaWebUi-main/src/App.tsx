import React, { useState } from 'react';
import { Search, Star, Check, Zap, Shield, Users, MapPin, Target, TrendingUp, Award, AlertCircle } from 'lucide-react';
import { SearchInterface } from './components/SearchInterface';
import { SearchFilters, SearchResult, EnhancedQuery } from './types/search';
import { searchListings, BackendSearchResult } from './services/api';

function App() {
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [activeTab, setActiveTab] = useState<'search' | 'pricing'>('search');
  const [currentEnhancedQuery, setCurrentEnhancedQuery] = useState<EnhancedQuery | null>(null);
  const [searchError, setSearchError] = useState<string | null>(null);

  const handleSearch = async (query: string, enhancedQuery: EnhancedQuery | null, filters: SearchFilters) => {
    if (!query.trim()) return;
    
    setIsSearching(true);
    setCurrentEnhancedQuery(enhancedQuery);
    setSearchError(null);
    setSearchResults([]);
    
    try {
      // Call the new Render backend API
      const backendResults = await searchListings(query);
      
      if (backendResults.length === 0) {
        setSearchError('No results found. Try different search terms or check back later.');
        return;
      }

      // Transform backend response to match frontend SearchResult format
      const transformedResults: SearchResult[] = backendResults.map((item: BackendSearchResult, index: number) => ({
        id: `${index + 1}`,
        title: item.title,
        price: parseFloat(item.price.replace(/[£$€,\s]/g, '')) || 0,
        currency: item.price.includes('£') ? 'GBP' : item.price.includes('€') ? 'EUR' : 'USD',
        location: 'UK', // Default to UK for now
        source: 'gumtree', // Default source
        image: item.image || 'https://images.pexels.com/photos/1751731/pexels-photo-1751731.jpeg?auto=compress&cs=tinysrgb&w=400',
        description: `${item.title} - Score: ${item.score}`,
        posted: 'Recently',
        isHighValue: enhancedQuery?.flags.high_value_item || false,
        scamRisk: enhancedQuery?.flags.common_scam_target ? 'medium' : 'low',
        url: item.link,
        score: item.score
      }));
      
      // Sort by score (highest first)
      transformedResults.sort((a, b) => (b.score || 0) - (a.score || 0));
      
      setSearchResults(transformedResults);
    } catch (error) {
      console.error('Search error:', error);
      
      const errorMessage = error instanceof Error ? error.message : 'Search failed. Please try again.';
      setSearchError(errorMessage);
      setSearchResults([]);
    } finally {
      setIsSearching(false);
    }
  };

  const pricingTiers = [
    {
      name: 'Free',
      price: 0,
      period: 'forever',
      features: [
        'Up to 10 searches per day',
        'Basic keyword search',
        'eBay & Facebook results',
        'Standard support'
      ],
      isPopular: false
    },
    {
      name: 'Pro',
      price: 12,
      period: 'month',
      features: [
        'Unlimited searches',
        'AI-powered query enhancement',
        'All marketplace sources',
        'Visual similarity matching',
        'Advanced filters',
        'Priority support'
      ],
      isPopular: true
    },
    {
      name: 'Reseller',
      price: 39,
      period: 'month',
      features: [
        'Everything in Pro',
        'Bulk search tools',
        'Profit margin calculator',
        'Market trend analysis',
        'API access',
        'Dedicated support'
      ],
      isPopular: false
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-800">
      {/* Header */}
      <header className="bg-black/90 backdrop-blur-sm border-b border-red-900/30 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <img 
                src="/logo.png" 
                alt="Hunta Logo" 
                className="h-8 w-auto"
              />
            </div>
            
            <nav className="hidden md:flex space-x-8">
              <button 
                onClick={() => setActiveTab('search')}
                className={`px-4 py-2 rounded-lg transition-all font-medium ${
                  activeTab === 'search' 
                    ? 'bg-red-600 text-white shadow-lg shadow-red-600/25' 
                    : 'text-gray-300 hover:text-red-400 hover:bg-gray-800/50'
                }`}
              >
                Search
              </button>
              <button 
                onClick={() => setActiveTab('pricing')}
                className={`px-4 py-2 rounded-lg transition-all font-medium ${
                  activeTab === 'pricing' 
                    ? 'bg-red-600 text-white shadow-lg shadow-red-600/25' 
                    : 'text-gray-300 hover:text-red-400 hover:bg-gray-800/50'
                }`}
              >
                Pricing
              </button>
            </nav>
          </div>
        </div>
      </header>

      {activeTab === 'search' && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Hero Section */}
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Hunt down the best
              <span className="block bg-gradient-to-r from-red-500 to-red-600 bg-clip-text text-transparent">
                second-hand deals
              </span>
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-8">
              Hunta uses AI to search eBay, Facebook Marketplace, Gumtree, and community forums 
              to find you the best prices on pre-owned items.
            </p>
            <div className="flex items-center justify-center space-x-8 text-sm text-gray-400">
              <div className="flex items-center space-x-2">
                <Target className="w-4 h-4 text-red-500" />
                <span>AI-Powered Search</span>
              </div>
              <div className="flex items-center space-x-2">
                <Shield className="w-4 h-4 text-red-500" />
                <span>Scam Detection</span>
              </div>
              <div className="flex items-center space-x-2">
                <TrendingUp className="w-4 h-4 text-red-500" />
                <span>Best Prices</span>
              </div>
            </div>
          </div>

          {/* Search Interface */}
          <SearchInterface onSearch={handleSearch} isSearching={isSearching} />

          {/* Search Results */}
          {searchResults.length > 0 && (
            <div className="max-w-6xl mx-auto">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold text-white">
                  Found {searchResults.length} results
                </h3>
                {currentEnhancedQuery && (
                  <div className="flex items-center space-x-2 text-sm text-gray-400">
                    <span>Sorted by: Relevance Score</span>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {searchResults.map((result) => (
                  <div key={result.id} className="bg-gray-900/80 backdrop-blur-sm rounded-xl shadow-2xl border border-gray-700/50 overflow-hidden hover:shadow-red-600/10 hover:border-red-600/30 transition-all duration-300 group">
                    <div className="relative">
                      <img 
                        src={result.image} 
                        alt={result.title}
                        className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute top-3 left-3">
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                          result.source === 'ebay' ? 'bg-yellow-600/20 text-yellow-400 border border-yellow-600/30' :
                          result.source === 'facebook' ? 'bg-blue-600/20 text-blue-400 border border-blue-600/30' :
                          result.source === 'gumtree' ? 'bg-green-600/20 text-green-400 border border-green-600/30' :
                          'bg-purple-600/20 text-purple-400 border border-purple-600/30'
                        }`}>
                          {result.source}
                        </span>
                      </div>
                      <div className="absolute top-3 right-3">
                        {result.isHighValue && (
                          <div className="bg-red-600/20 text-red-400 border border-red-600/30 px-2 py-1 text-xs font-medium rounded-full">
                            <Star className="w-3 h-3 inline mr-1" />
                            High Value
                          </div>
                        )}
                        {currentEnhancedQuery?.flags.reseller_friendly && (
                          <div className="bg-purple-600/20 text-purple-400 border border-purple-600/30 px-2 py-1 text-xs font-medium rounded-full mt-1">
                            Reseller
                          </div>
                        )}
                        {result.score && result.score > 0.8 && (
                          <div className="bg-blue-600/20 text-blue-400 border border-blue-600/30 px-2 py-1 text-xs font-medium rounded-full mt-1">
                            <Award className="w-3 h-3 inline mr-1" />
                            Top Match
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="p-4">
                      <h4 className="font-semibold text-white mb-2 line-clamp-2">
                        {result.title}
                      </h4>
                      <p className="text-gray-400 text-sm mb-3 line-clamp-2">
                        {result.description}
                      </p>
                      
                      <div className="flex items-center justify-between mb-3">
                        <div className="text-2xl font-bold text-red-500">
                          ${result.price}
                        </div>
                        <div className={`flex items-center space-x-1 text-xs ${
                          result.scamRisk === 'low' ? 'text-green-400' :
                          result.scamRisk === 'medium' ? 'text-yellow-400' :
                          'text-red-400'
                        }`}>
                          <Shield className="w-3 h-3" />
                          <span>{result.scamRisk} risk</span>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between text-sm text-gray-500 mb-3">
                        <span className="flex items-center">
                          <MapPin className="w-4 h-4 mr-1" />
                          {result.location}
                        </span>
                        <span>{result.posted}</span>
                      </div>
                      
                      <a 
                        href={result.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="block w-full py-2 bg-gradient-to-r from-red-600 to-red-700 text-white rounded-lg hover:from-red-700 hover:to-red-800 transition-all text-sm font-medium shadow-lg shadow-red-600/25 text-center"
                      >
                        View Listing
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Error State */}
          {searchError && (
            <div className="max-w-4xl mx-auto">
              <div className="bg-red-900/20 border border-red-600/30 rounded-xl p-8 text-center">
                <div className="w-16 h-16 bg-red-600/20 border border-red-600/30 rounded-full flex items-center justify-center mx-auto mb-4">
                  <AlertCircle className="w-8 h-8 text-red-500" />
                </div>
                <h3 className="text-xl font-semibold text-red-400 mb-2">Search Error</h3>
                <p className="text-gray-300 mb-4">{searchError}</p>
                <button 
                  onClick={() => setSearchError(null)}
                  className="px-4 py-2 bg-red-600/20 text-red-400 border border-red-600/30 rounded-lg hover:bg-red-600/30 transition-colors"
                >
                  Try Again
                </button>
              </div>
            </div>
          )}

          {/* No Results State */}
          {!isSearching && !searchError && searchResults.length === 0 && currentEnhancedQuery && (
            <div className="max-w-4xl mx-auto">
              <div className="bg-gray-900/50 border border-gray-700/50 rounded-xl p-8 text-center">
                <div className="w-16 h-16 bg-gray-700/50 border border-gray-600/30 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Search className="w-8 h-8 text-gray-500" />
                </div>
                <h3 className="text-xl font-semibold text-gray-300 mb-2">No Results Found</h3>
                <p className="text-gray-400 mb-4">
                  We couldn't find any listings matching your search. Try different keywords or check back later.
                </p>
                <div className="flex flex-wrap justify-center gap-2 text-sm">
                  <span className="text-gray-500">Suggestions:</span>
                  <span className="bg-gray-800 border border-gray-600 px-2 py-1 rounded text-gray-300">Try broader terms</span>
                  <span className="bg-gray-800 border border-gray-600 px-2 py-1 rounded text-gray-300">Check spelling</span>
                  <span className="bg-gray-800 border border-gray-600 px-2 py-1 rounded text-gray-300">Use brand names</span>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === 'pricing' && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Choose your plan
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Start saving money on second-hand purchases with our intelligent search platform
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {pricingTiers.map((tier) => (
              <div key={tier.name} className={`relative bg-gray-900/80 backdrop-blur-sm rounded-2xl shadow-2xl border-2 transition-all duration-300 hover:shadow-red-600/10 ${
                tier.isPopular ? 'border-red-600 scale-105 shadow-red-600/20' : 'border-gray-700/50 hover:border-red-600/30'
              }`}>
                {tier.isPopular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <div className="bg-gradient-to-r from-red-600 to-red-700 text-white px-4 py-2 rounded-full text-sm font-medium shadow-lg">
                      Most Popular
                    </div>
                  </div>
                )}
                
                <div className="p-8">
                  <div className="text-center mb-8">
                    <h3 className="text-2xl font-bold text-white mb-2">{tier.name}</h3>
                    <div className="flex items-center justify-center">
                      <span className="text-4xl font-bold text-white">${tier.price}</span>
                      <span className="text-gray-400 ml-2">/{tier.period}</span>
                    </div>
                  </div>
                  
                  <ul className="space-y-4 mb-8">
                    {tier.features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <Check className="h-5 w-5 text-red-500 mt-0.5 mr-3 flex-shrink-0" />
                        <span className="text-gray-300">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <button className={`w-full py-3 px-6 rounded-xl font-medium transition-all ${
                    tier.isPopular 
                      ? 'bg-gradient-to-r from-red-600 to-red-700 text-white hover:from-red-700 hover:to-red-800 shadow-lg shadow-red-600/25' 
                      : 'bg-gray-800 text-gray-300 hover:bg-gray-700 border border-gray-600'
                  }`}>
                    {tier.name === 'Free' ? 'Get Started' : `Start ${tier.name} Plan`}
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-16 text-center">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
              <div className="flex flex-col items-center">
                <div className="w-12 h-12 bg-red-600/20 border border-red-600/30 rounded-full flex items-center justify-center mb-4">
                  <Zap className="w-6 h-6 text-red-500" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">AI-Powered Search</h3>
                <p className="text-gray-400">Our AI understands your queries and finds the best matches across all platforms</p>
              </div>
              
              <div className="flex flex-col items-center">
                <div className="w-12 h-12 bg-red-600/20 border border-red-600/30 rounded-full flex items-center justify-center mb-4">
                  <Shield className="w-6 h-6 text-red-500" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">Scam Detection</h3>
                <p className="text-gray-400">Advanced algorithms help identify potentially fraudulent listings</p>
              </div>
              
              <div className="flex flex-col items-center">
                <div className="w-12 h-12 bg-red-600/20 border border-red-600/30 rounded-full flex items-center justify-center mb-4">
                  <Users className="w-6 h-6 text-red-500" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">Community Forums</h3>
                <p className="text-gray-400">Access exclusive deals from niche communities and forums</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-black border-t border-gray-800 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <img 
                  src="/logo.png" 
                  alt="Hunta Logo" 
                  className="h-8 w-auto"
                />
              </div>
              <p className="text-gray-400 max-w-md">
                The smart way to find second-hand deals. Save money and discover hidden gems across all major marketplaces and forums.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4 text-red-500">Product</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-red-400 transition-colors">Search</a></li>
                <li><a href="#" className="hover:text-red-400 transition-colors">Pricing</a></li>
                <li><a href="#" className="hover:text-red-400 transition-colors">API</a></li>
                <li><a href="#" className="hover:text-red-400 transition-colors">Mobile App</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4 text-red-500">Company</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-red-400 transition-colors">About</a></li>
                <li><a href="#" className="hover:text-red-400 transition-colors">Blog</a></li>
                <li><a href="#" className="hover:text-red-400 transition-colors">Careers</a></li>
                <li><a href="#" className="hover:text-red-400 transition-colors">Contact</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2025 Hunta. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;