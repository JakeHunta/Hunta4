export interface SearchFilters {
  location: string;
  currency: string;
  sources: string[];
  priceRange: [number, number];
}

export interface SearchResult {
  id: string;
  title: string;
  price: number;
  currency: string;
  location: string;
  source: string;
  image: string;
  description: string;
  posted: string;
  isHighValue: boolean;
  scamRisk: 'low' | 'medium' | 'high';
  url: string;
  score?: number;
}

export interface EnhancedQuery {
  original: string;
  search_terms: string[];
  categories: string[];
  forums: string[];
  flags: {
    high_value_item: boolean;
    common_scam_target: boolean;
    likely_on_forums: boolean;
    reseller_friendly: boolean;
  };
}