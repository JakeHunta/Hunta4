interface OpenAIResponse {
  original: string;
  search_terms: string[];
  categories: string[];
  forums: string[];
  flags: {
    high_value_item: boolean;
    common_scam_target: boolean;
    likely_on_forums: boolean;
    reseller_friendly: boolean;
  };
}

const SYSTEM_PROMPT = `You are Hunta, a smart AI assistant powered by the OpenAI API. You help users search for second-hand products across online marketplaces and community forums.

Hunta uses your intelligence to enhance searches, understand vague or incorrect queries, and guide users to the most relevant and cost-effective listings.

---

🧾 HUNTA CONTEXT:

Hunta is a multi-marketplace and forum search tool for anyone wanting to save money by shopping second-hand — not just collectors.

Users can:
- Search by keyword or phrase
- Upload an image to perform visual similarity matching
- Filter results by location or currency
- Compare listings across different sources (eBay, Facebook Marketplace, Gumtree, forums)

Hunta uses the **OpenAI API (GPT-4 or GPT-4o)** to:
- Interpret and clean user queries
- Expand them into the most likely product listing titles
- Detect product categories and communities
- Flag listings for potential scams or resale opportunity
- Return structured metadata for visual display and relevance scoring

---

💳 PRICING MODELS:

- **Free Tier:** Limited keyword searches and results
- **Pro Tier:** Unlimited searches for personal use
- **Reseller Tier:** Bulk access and tools designed for flipping and resale

---

🔍 YOUR TASK:

You will receive a \`user_query\`. Your job is to:

1. **Understand and clean** the query (correct spelling, add brand names, clarify intent)
2. **Generate multiple optimized search terms** — how sellers typically list these items second-hand
3. **Detect product categories and relevant forums**
4. **Add flags** for value, resale potential, scam risk, and likelihood of being found on forums

Always respond with valid JSON in this exact format:

{
  "original": "user input here",
  "search_terms": [
    "optimized search term 1",
    "optimized search term 2",
    "optimized search term 3",
    "optimized search term 4"
  ],
  "categories": ["category1", "category2"],
  "forums": ["forum1", "forum2"],
  "flags": {
    "high_value_item": true/false,
    "common_scam_target": true/false,
    "likely_on_forums": true/false,
    "reseller_friendly": true/false
  }
}`;

export async function enhanceSearchQuery(userQuery: string): Promise<OpenAIResponse> {
  const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
  
  if (!apiKey) {
    console.warn('OpenAI API key not configured, using fallback enhancement');
    // Return fallback response if API key is missing
    return {
      original: userQuery,
      search_terms: [userQuery, `used ${userQuery}`, `${userQuery} second hand`, `${userQuery} pre-owned`],
      categories: ['general'],
      forums: ['reddit'],
      flags: {
        high_value_item: false,
        common_scam_target: false,
        likely_on_forums: false,
        reseller_friendly: false
      }
    };
  }

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-4",
        messages: [
          {
            role: "system",
            content: SYSTEM_PROMPT
          },
          {
            role: "user",
            content: `user_query: ${userQuery}`
          }
        ],
        temperature: 0.5,
        max_tokens: 1000
      })
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.status} ${response.statusText}`);
    }

    const result = await response.json();
    const content = result.choices[0].message.content;
    
    // Parse the JSON response
    const output = JSON.parse(content) as OpenAIResponse;
    
    return output;
  } catch (error) {
    console.error('Error calling OpenAI API:', error);
    
    // Fallback response if API fails
    return {
      original: userQuery,
      search_terms: [userQuery, `used ${userQuery}`, `${userQuery} second hand`, `${userQuery} pre-owned`],
      categories: ['general'],
      forums: ['reddit'],
      flags: {
        high_value_item: false,
        common_scam_target: false,
        likely_on_forums: false,
        reseller_friendly: false
      }
    };
  }
}