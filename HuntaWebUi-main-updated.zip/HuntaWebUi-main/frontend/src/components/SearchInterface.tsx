import React, { useState } from 'react';
import { Search, Upload, MapPin, DollarSign, Filter, Sparkles, AlertCircle, TrendingUp, Users, Target } from 'lucide-react';
import { SearchFilters, EnhancedQuery } from '../types/search';
import { enhanceSearchQuery } from '../services/openai';
import { checkApiHealth } from '../services/api';

interface SearchInterfaceProps {
  onSearch: (query: string, enhancedQuery: EnhancedQuery | null, filters: SearchFilters) => void;
  isSearching: boolean;
}

export function SearchInterface({ onSearch, isSearching }: SearchInterfaceProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const [enhancedQuery, setEnhancedQuery] = useState<EnhancedQuery | null>(null);
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [apiStatus, setApiStatus] = useState<'checking' | 'online' | 'offline'>('checking');
  
  const [filters, setFilters] = useState<SearchFilters>({
    location: '',
    currency: 'USD',
    sources: ['ebay', 'facebook', 'gumtree', 'forums'],
    priceRange: [0, 1000]
  });

  // Check API health on component mount
  React.useEffect(() => {
    const checkHealth = async () => {
      try {
        const isHealthy = await checkApiHealth();
        setApiStatus(isHealthy ? 'online' : 'offline');
      } catch {
        setApiStatus('offline');
      }
    };
    
    checkHealth();
  }, []);
  const handleSearch = async () => {
    if (!searchQuery.trim() && !selectedFile) return;
    
    setIsEnhancing(true);
    
    try {
      // Enhance the search query using OpenAI
      const enhanced = await enhanceSearchQuery(searchQuery);
      setEnhancedQuery(enhanced);
      
      // Proceed with search
      setIsEnhancing(false);
      onSearch(searchQuery, enhanced, filters);
    } catch (error) {
      console.error('Failed to enhance query:', error);
      // Proceed with original query if enhancement fails
      setIsEnhancing(false);
      onSearch(searchQuery, null, filters);
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  return (
    <div className="max-w-4xl mx-auto mb-12">
      <div className="bg-gray-900/80 backdrop-blur-sm rounded-2xl shadow-2xl border border-gray-700/50 p-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Text Search */}
          <div className="space-y-4">
            <label className="block text-sm font-medium text-gray-300">
              Search by keyword or description
            </label>
            <div className="relative">
              <Search className="absolute left-3 top-3.5 h-5 w-5 text-gray-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="e.g., strymon ob1, vintage guitar, macbook pro"
                className="w-full pl-10 pr-4 py-3 bg-gray-800/50 border border-gray-600 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-red-500 transition-all text-white placeholder-gray-400"
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              />
            </div>
            
            {/* API Status Indicator */}
            <div className="flex items-center space-x-2 text-xs">
              <div className={`w-2 h-2 rounded-full ${
                apiStatus === 'online' ? 'bg-green-500' : 
                apiStatus === 'offline' ? 'bg-red-500' : 
                'bg-yellow-500 animate-pulse'
              }`} />
              <span className={`${
                apiStatus === 'online' ? 'text-green-400' : 
                apiStatus === 'offline' ? 'text-red-400' : 
                'text-yellow-400'
              }`}>
                {apiStatus === 'online' ? 'Search API Online' : 
                 apiStatus === 'offline' ? 'Search API Offline' : 
                 'Checking API Status...'}
              </span>
            </div>
          </div>

          {/* Image Search */}
          <div className="space-y-4">
            <label className="block text-sm font-medium text-gray-300">
              Or upload an image for visual search
            </label>
            <div className="relative">
              <input
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
                id="image-upload"
              />
              <label
                htmlFor="image-upload"
                className="flex items-center justify-center w-full py-3 border-2 border-dashed border-gray-600 rounded-xl cursor-pointer hover:border-red-500 transition-all bg-gray-800/30"
              >
                <Upload className="h-5 w-5 text-gray-500 mr-2" />
                <span className="text-gray-400">
                  {selectedFile ? selectedFile.name : 'Click to upload image'}
                </span>
              </label>
            </div>
          </div>
        </div>

        {/* Enhanced Query Display */}
        {enhancedQuery && (
          <div className="mt-6 p-4 bg-gradient-to-r from-red-900/20 to-gray-800/20 rounded-xl border border-red-600/30">
            <div className="flex items-center mb-3">
              <Target className="h-5 w-5 text-red-500 mr-2" />
              <h3 className="font-medium text-red-400">AI-Enhanced Search</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div>
                <p className="font-medium text-gray-300 mb-2">Optimized Search Terms:</p>
                <div className="space-y-1">
                  {enhancedQuery.search_terms.map((term, index) => (
                    <span key={index} className="inline-block bg-gray-800 border border-gray-600 px-2 py-1 rounded-md text-gray-300 mr-2 mb-1">
                      {term}
                    </span>
                  ))}
                </div>
              </div>
              
              <div>
                <p className="font-medium text-gray-300 mb-2">Categories & Forums:</p>
                <div className="space-y-1">
                  {enhancedQuery.categories.map((category, index) => (
                    <span key={index} className="inline-block bg-red-600/20 text-red-400 border border-red-600/30 px-2 py-1 rounded-md text-xs mr-2 mb-1">
                      {category}
                    </span>
                  ))}
                  {enhancedQuery.forums.map((forum, index) => (
                    <span key={index} className="inline-block bg-gray-700/50 text-gray-300 border border-gray-600 px-2 py-1 rounded-md text-xs mr-2 mb-1">
                      {forum}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Flags */}
            <div className="flex flex-wrap gap-2 mt-3">
              {enhancedQuery.flags.high_value_item && (
                <span className="flex items-center bg-yellow-600/20 text-yellow-400 border border-yellow-600/30 px-2 py-1 rounded-md text-xs">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  High Value
                </span>
              )}
              {enhancedQuery.flags.common_scam_target && (
                <span className="flex items-center bg-red-600/20 text-red-400 border border-red-600/30 px-2 py-1 rounded-md text-xs">
                  <AlertCircle className="w-3 h-3 mr-1" />
                  Scam Risk
                </span>
              )}
              {enhancedQuery.flags.likely_on_forums && (
                <span className="flex items-center bg-purple-600/20 text-purple-400 border border-purple-600/30 px-2 py-1 rounded-md text-xs">
                  <Users className="w-3 h-3 mr-1" />
                  Forum Deals
                </span>
              )}
              {enhancedQuery.flags.reseller_friendly && (
                <span className="flex items-center bg-green-600/20 text-green-400 border border-green-600/30 px-2 py-1 rounded-md text-xs">
                  <DollarSign className="w-3 h-3 mr-1" />
                  Reseller Friendly
                </span>
              )}
            </div>
          </div>
        )}

        {/* Filters */}
        <div className="mt-6 pt-6 border-t border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center space-x-2 text-gray-400 hover:text-red-400 transition-colors"
            >
              <Filter className="h-4 w-4" />
              <span>Advanced Filters</span>
            </button>
            
            <button
              onClick={handleSearch}
              disabled={isSearching || isEnhancing || (!searchQuery.trim() && !selectedFile) || apiStatus === 'offline'}
              className="px-8 py-3 bg-gradient-to-r from-red-600 to-red-700 text-white rounded-xl font-medium hover:from-red-700 hover:to-red-800 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center space-x-2 shadow-lg shadow-red-600/25"
            >
              {isEnhancing ? (
                <>
                  <Target className="h-4 w-4 animate-pulse" />
                  <span>Enhancing...</span>
                </>
              ) : isSearching ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                  <span>Searching...</span>
                </>
              ) : (
                <>
                  <Search className="h-4 w-4" />
                  <span>Hunt</span>
                </>
              )}
            </button>
            
            {apiStatus === 'offline' && (
              <div className="text-xs text-red-400 mt-2">
                Search service is currently unavailable
              </div>
            )}
          </div>

          {showFilters && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Location
                </label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-500" />
                  <input
                    type="text"
                    value={filters.location}
                    onChange={(e) => setFilters({...filters, location: e.target.value})}
                    placeholder="City, State"
                    className="w-full pl-9 pr-3 py-2 bg-gray-800/50 border border-gray-600 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 text-white placeholder-gray-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Currency
                </label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-3 h-4 w-4 text-gray-500" />
                  <select
                    value={filters.currency}
                    onChange={(e) => setFilters({...filters, currency: e.target.value})}
                    className="w-full pl-9 pr-3 py-2 bg-gray-800/50 border border-gray-600 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 text-white"
                  >
                    <option value="USD">USD</option>
                    <option value="EUR">EUR</option>
                    <option value="GBP">GBP</option>
                    <option value="CAD">CAD</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Price Range
                </label>
                <div className="flex space-x-2">
                  <input
                    type="number"
                    value={filters.priceRange[0]}
                    onChange={(e) => setFilters({...filters, priceRange: [Number(e.target.value), filters.priceRange[1]]})}
                    placeholder="Min"
                    className="w-full px-3 py-2 bg-gray-800/50 border border-gray-600 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 text-white placeholder-gray-400"
                  />
                  <input
                    type="number"
                    value={filters.priceRange[1]}
                    onChange={(e) => setFilters({...filters, priceRange: [filters.priceRange[0], Number(e.target.value)]})}
                    placeholder="Max"
                    className="w-full px-3 py-2 bg-gray-800/50 border border-gray-600 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 text-white placeholder-gray-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Sources
                </label>
                <div className="space-y-2">
                  {['ebay', 'facebook', 'gumtree', 'forums'].map((source) => (
                    <label key={source} className="flex items-center">
                      <input
                        type="checkbox"
                        checked={filters.sources.includes(source)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setFilters({...filters, sources: [...filters.sources, source]});
                          } else {
                            setFilters({...filters, sources: filters.sources.filter(s => s !== source)});
                          }
                        }}
                        className="rounded border-gray-600 bg-gray-800 text-red-600 focus:ring-red-500"
                      />
                      <span className="ml-2 text-sm text-gray-400 capitalize">{source}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}