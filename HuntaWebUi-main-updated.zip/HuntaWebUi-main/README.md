# Hunta - Smart Second-Hand Marketplace Search

A comprehensive search tool that uses AI to find the best second-hand deals across multiple marketplaces including eBay, Gumtree, and community forums.

## 🚀 Quick Start

### 1. Install Dependencies
```bash
npm run install:all
```

### 2. Configure Environment Variables

#### Backend Configuration
```bash
cd backend
cp .env.example .env
```

Edit `backend/.env` with your API keys:
```env
OPENAI_API_KEY=your_openai_api_key_here
SCRAPINGBEE_API_KEY=your_scrapingbee_api_key_here
PORT=3001
NODE_ENV=development
```

#### Frontend Configuration
```bash
cd frontend
cp .env.example .env
```

Edit `frontend/.env`:
```env
VITE_OPENAI_API_KEY=your_openai_api_key_here
VITE_API_BASE_URL=http://localhost:3001
```

### 3. Start Development Servers
```bash
npm run dev
```

This will start:
- Frontend: http://localhost:5173 (visible in Bolt preview)
- Backend: http://localhost:3001

## 🏗️ Project Structure

```
hunta/
├── frontend/               # React frontend
│   ├── src/
│   │   ├── components/     # React components
│   │   ├── services/       # API services
│   │   ├── types/          # TypeScript types
│   │   └── App.tsx         # Main app component
│   ├── public/             # Static assets
│   └── vite.config.ts      # Vite configuration with proxy
├── backend/                # Node.js backend
│   ├── services/           # Business logic services
│   ├── utils/              # Utility functions
│   └── server.js           # Express server
└── package.json            # Root package.json with scripts
```

## 🔧 Available Scripts

- `npm run dev` - Start both frontend and backend servers
- `npm run dev:frontend` - Start only the frontend server
- `npm run dev:backend` - Start only the backend server
- `npm run install:all` - Install dependencies for all packages
- `npm run build` - Build the frontend for production

## 🌟 Features

### Frontend
- **Dark Theme UI** - Modern, professional interface
- **Keyword Search** - AI-enhanced search queries
- **Image Search** - Visual similarity matching (planned)
- **Advanced Filters** - Location, price range, source filtering
- **Real-time Results** - Live search with scoring and ranking
- **Responsive Design** - Works on all device sizes

### Backend Integration
- **AI Query Enhancement** - OpenAI GPT-4 optimizes search terms
- **Multi-Marketplace Scraping** - eBay, Gumtree via ScrapingBee
- **Intelligent Scoring** - Relevance-based result ranking
- **Caching System** - 5-minute response caching
- **Rate Limiting** - Production-ready security
- **Health Monitoring** - API status and service checks

## 🔑 API Keys Setup

### OpenAI API Key
1. Visit [OpenAI Platform](https://platform.openai.com/api-keys)
2. Create a new API key
3. Add to both `backend/.env` and `frontend/.env`

### ScrapingBee API Key
1. Visit [ScrapingBee](https://www.scrapingbee.com/)
2. Sign up for an account
3. Get your API key from the dashboard
4. Add to `backend/.env` as `SCRAPINGBEE_API_KEY`

## 📡 API Endpoints

### POST /search
Search for second-hand items across marketplaces.

**Request:**
```json
{
  "search_term": "strymon ob1"
}
```

**Response:**
```json
[
  {
    "title": "Strymon OB.1 Optical Compressor Pedal",
    "image": "https://example.com/image.jpg",
    "price": "£280",
    "link": "https://www.ebay.com/itm/123456",
    "source": "ebay",
    "description": "Strymon OB.1 Optical Compressor Pedal",
    "score": 0.92
  }
]
```

### GET /health
Check API health and service status.

## 🔧 Development Setup

### Vite Proxy Configuration
The frontend uses Vite's proxy feature to route `/api/*` requests to the backend server at `http://localhost:3001`. This ensures seamless development and avoids CORS issues.

### Environment Variables
- Frontend uses `VITE_` prefixed environment variables
- Backend uses standard Node.js environment variables
- Both can be configured independently

### Hot Reloading
- Frontend: Vite provides instant hot module replacement
- Backend: Uses `--watch` flag for automatic restarts

## 🚀 Deployment

### Frontend (Vercel, Netlify, etc.)
```bash
cd frontend
npm run build
```

### Backend (Render, Railway, Heroku, etc.)
The backend is ready for deployment with proper environment variable configuration.

## 🛠️ Troubleshooting

### Common Issues

1. **"Cannot connect to backend"**
   - Ensure backend server is running on port 3001
   - Check `VITE_API_BASE_URL` in frontend/.env

2. **"OpenAI API key not configured"**
   - Set `OPENAI_API_KEY` in backend/.env
   - Set `VITE_OPENAI_API_KEY` in frontend/.env

3. **"ScrapingBee API key not configured"**
   - Set `SCRAPINGBEE_API_KEY` in backend/.env

4. **Preview not loading in Bolt**
   - Ensure frontend server is running on port 5173
   - Check Vite configuration for host settings

## 📝 License

MIT License - see LICENSE file for details.